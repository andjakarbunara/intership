/**
 * 
 */
/**
 * @author Mirton
 *
 */
module crud {
	requires java.sql;
}