package crud;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class main {
	
	
	public  void operations() {
		
	System.out.println("Welcome!");
	String url="jdbc:mysql://localhost:3306/intershipi";
    String username = "root";
    String Password = "njegjeqetambajmend123@";
    
    Scanner scanner = new Scanner(System.in);
    String userChoice;
    	
		do {
			System.out.println("Select options from below menu:");
            System.out.println("Press 1 to Select data");
            System.out.println("Press 2 to Insert data");
            System.out.println("Press 3 to Delete data");
            System.out.println("Press 4 to Exit");
            
            userChoice = scanner.nextLine();
    	
    	switch(userChoice) {
    	
    	case "1":
    		try(Connection con = DriverManager.getConnection(url, username, Password);
    				Statement st = con.createStatement()) {
    			
                String query = "SELECT * FROM inter";
                ResultSet rs = st.executeQuery(query);
                
                while(rs.next()) {
                	String firstname = rs.getString("firstname");
                    String lastname = rs.getString("lastname");
                    System.out.println("First Name: " + firstname + ", Last Name: " + lastname);
                }
    	}
    		catch(SQLException e) {
    			e.printStackTrace();
    		}
    		break;
    		
    		
    		
    	case "2":
    		try (Connection con = DriverManager.getConnection(url, username, Password)) {
    			
    			System.out.println("Enter first name:");
    			var fn = scanner.nextLine();
    			System.out.println("Enter last name:");
    			var ln = scanner.nextLine();
    			System.out.println("Enter password :");
    			var pass = scanner.nextLine();
    			
    			String query = "INSERT INTO inter (firstname, lastname, password) VALUES (?, ?, ?)";
    			
    			PreparedStatement pst = con.prepareStatement(query);
    			pst.setString(1, fn);
    			pst.setString(2, ln);
    			pst.setString(3, pass);
    			pst.executeUpdate();
    			
    		    System.out.println("Data entered successfully!");
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}break;
    
    	
    	
    	
    	
    	case "3":
    		try (Connection con = DriverManager.getConnection(url, username, Password)) {
    			
    			System.out.println("Enter the firat and lastname of the person you want to delete : ");
    			var fn=scanner.nextLine();
    			var ln=scanner.nextLine();
    			
    			String query = "DELETE FROM inter WHERE  firstname =? AND lastname =? ";
    			PreparedStatement pst = con.prepareStatement(query);
    			pst.setString(1, fn);
    			pst.setString(2, ln);
    			pst.executeUpdate();
    			
    			System.out.println("Data deleted successfully!");
    		}catch(SQLException e) {
    			e.printStackTrace();
    		}break;
    		
    		
    		
    	
    	 case "4":
             System.out.println("Exiting program...");
             break;
         
             
         default:
             System.out.println("Invalid choice, please try again.");
    	}
    	
    	} while(!userChoice.equals("4"));
		
		scanner.close();    	 
}
	
	
	
	
	public static void main(String[] args) {
        main main = new main();
        main.operations();
    }
}
