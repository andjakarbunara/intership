package maven;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		car car=new car();
		car.drive();
		
    ApplicationContext apc=new ClassPathXmlApplicationContext("spring.xml");
		
		vehicle obj = (vehicle) apc.getBean("car");
		obj.drive();

	}

}
