package maven;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//car car=new car();
		//car.drive();
		
    ApplicationContext apc=new ClassPathXmlApplicationContext("spring.xml");
		
		//vehicle obj = (vehicle)context.getBean("car");
        // obj.drive();
    
    car obj = (car)apc.getBean("car");
    obj.drive();
    
    
   // tyre t = new tyre(); kjo do me jepte dependencies
    
    /*tyre t = (tyre) apc.getBean("tyre");
    System.out.print(t);*/
    
    
    
    

	}

}
