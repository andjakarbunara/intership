package maven;

public interface vehicle {
	void drive();

}
