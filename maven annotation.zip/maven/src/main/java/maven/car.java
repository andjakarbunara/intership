package maven;

import org.springframework.stereotype.Component;



@Component
public class car implements vehicle{

	
	
	
	public void drive() {
		System.out.print("It is driving");
	}
	
	
	
}
