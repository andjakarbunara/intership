package maven;

public class bike implements vehicle{
	
	public void drive() {
	System.out.print("It is riding");
	}
}
